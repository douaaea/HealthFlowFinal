package com.example.proxy_fhir;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProxyFhirApplicationTests {

	@Test
	void contextLoads() {
	}

}
